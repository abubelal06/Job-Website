// Add the following to script.js to handle dynamic job listings and newsletter submission:

document.addEventListener('DOMContentLoaded', function () {
    const jobListContainer = document.getElementById('job-listings');
  
    // Example job listings
    const jobs = [
      {
        jobTitle: 'Software Engineer',
        companyName: 'Tech Solutions',
        jobDescription: 'Develop and maintain web applications.',
        location: 'Remote',
        category: 'Technology'
      },
      {
        jobTitle: 'Product Manager',
        companyName: 'Innovate Corp',
        jobDescription: 'Lead product development teams.',
        location: 'New York, NY',
        category: 'Marketing'
      },
      {
        jobTitle: 'UI/UX Designer',
        companyName: 'DesignTech',
        jobDescription: 'Create intuitive and engaging user interfaces.',
        location: 'San Francisco, CA',
        category: 'Design'
      },
    ];
  
    // Create and append job cards dynamically
    jobs.forEach(job => {
      const jobDiv = document.createElement('div');
      jobDiv.classList.add('job-item');
      jobDiv.innerHTML = `
        <h3>${job.jobTitle}</h3>
        <p><strong>Company:</strong> ${job.companyName}</p>
        <p><strong>Description:</strong> ${job.jobDescription}</p>
        <p><strong>Location:</strong> ${job.location}</p>
        <p><strong>Category:</strong> ${job.category}</p>
      `;
      jobListContainer.appendChild(jobDiv);
    });
  
    // Newsletter form submission
    document.getElementById('newsletter-form').addEventListener('submit', function (event) {
      event.preventDefault();
      const email = event.target.querySelector('input').value;
      alert('Subscribed successfully with email: ' + email);
    });
  });
  